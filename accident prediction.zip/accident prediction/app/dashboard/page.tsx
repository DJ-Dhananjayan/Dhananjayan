"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  AlertTriangle,
  Bell,
  Car,
  Clock,
  LogOut,
  MapPin,
  Settings,
  Shield,
  User,
  AlertOctagon,
  X,
  PhoneCall,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useMobile } from "@/hooks/use-mobile"

export default function DashboardPage() {
  const [currentSpeed, setCurrentSpeed] = useState(45)
  const [speedLimit, setSpeedLimit] = useState(60)
  const [safetyScore, setSafetyScore] = useState(87)
  const [showAccidentAlert, setShowAccidentAlert] = useState(false)
  const [countdown, setCountdown] = useState(10)
  const [emergencyDialogOpen, setEmergencyDialogOpen] = useState(false)
  const isMobile = useMobile()

  // Simulate speed changes
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSpeed((prev) => {
        const change = Math.floor(Math.random() * 5) - 2 // -2 to +2
        return Math.max(0, prev + change)
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Simulate accident alert after 10 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowAccidentAlert(true)
    }, 10000)

    return () => clearTimeout(timer)
  }, [])

  // Countdown timer for accident alert
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (showAccidentAlert && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1)
      }, 1000)
    }

    if (countdown === 0) {
      setShowAccidentAlert(false)
      setEmergencyDialogOpen(true)
    }

    return () => clearInterval(timer)
  }, [showAccidentAlert, countdown])

  const cancelAlert = () => {
    setShowAccidentAlert(false)
    setCountdown(10)
  }

  const getSpeedColor = () => {
    if (currentSpeed > speedLimit) return "text-red-600"
    if (currentSpeed > speedLimit * 0.8) return "text-amber-500"
    return "text-green-600"
  }

  const getSafetyScoreColor = () => {
    if (safetyScore >= 80) return "text-green-600"
    if (safetyScore >= 60) return "text-amber-500"
    return "text-red-600"
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Car className="h-6 w-6 text-red-600" />
            <h1 className="text-xl font-bold">SafeDrive AI</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Link href="/login">
              <Button variant="ghost" size="icon">
                <LogOut className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {showAccidentAlert && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4 shadow-lg">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center">
                <AlertOctagon className="h-8 w-8 text-red-600 mr-2" />
                <h2 className="text-xl font-bold text-red-600">Potential Accident Detected!</h2>
              </div>
              <Button variant="ghost" size="icon" onClick={cancelAlert}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <p className="mb-4">
              Our AI has detected a potential accident scenario. Emergency services will be contacted in:
            </p>
            <div className="flex justify-center mb-4">
              <div className="bg-red-100 text-red-600 text-4xl font-bold rounded-full w-20 h-20 flex items-center justify-center">
                {countdown}
              </div>
            </div>
            <p className="text-sm text-gray-500 mb-4 text-center">Press "Cancel Alert" if this is a false alarm</p>
            <Button className="w-full bg-red-600 hover:bg-red-700" onClick={cancelAlert}>
              Cancel Alert
            </Button>
          </div>
        </div>
      )}

      <Dialog open={emergencyDialogOpen} onOpenChange={setEmergencyDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <PhoneCall className="mr-2 h-5 w-5" />
              Emergency Call in Progress
            </DialogTitle>
            <DialogDescription>
              Contacting emergency services (108) with your location and vehicle information.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="h-20 w-20 rounded-full bg-red-100 flex items-center justify-center">
                  <PhoneCall className="h-10 w-10 text-red-600 animate-pulse" />
                </div>
                <div className="absolute -inset-1 rounded-full border-2 border-red-400 animate-ping opacity-75"></div>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">Sharing the following information:</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Vehicle registration: ABC-1234</li>
                <li>• Current location: 123 Main St, City</li>
                <li>• Driver: John Doe</li>
                <li>• Emergency contact: Jane Doe (Parent)</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="destructive" onClick={() => setEmergencyDialogOpen(false)}>
              End Call
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Current Speed</CardTitle>
              <CardDescription>Vehicle speed monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className={`text-4xl font-bold ${getSpeedColor()}`}>
                  {currentSpeed}
                  <span className="text-lg ml-1">km/h</span>
                </div>
                <div className="text-sm text-gray-500">Limit: {speedLimit} km/h</div>
              </div>
              <Progress
                value={(currentSpeed / speedLimit) * 100}
                className="h-2 mt-2"
                indicatorClassName={
                  currentSpeed > speedLimit
                    ? "bg-red-600"
                    : currentSpeed > speedLimit * 0.8
                      ? "bg-amber-500"
                      : "bg-green-600"
                }
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Safety Score</CardTitle>
              <CardDescription>Based on driving patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className={`text-4xl font-bold ${getSafetyScoreColor()}`}>
                  {safetyScore}
                  <span className="text-lg ml-1">/ 100</span>
                </div>
                <Badge variant={safetyScore >= 80 ? "outline" : safetyScore >= 60 ? "secondary" : "destructive"}>
                  {safetyScore >= 80 ? "Safe Driver" : safetyScore >= 60 ? "Moderate Risk" : "High Risk"}
                </Badge>
              </div>
              <Progress
                value={safetyScore}
                className="h-2 mt-2"
                indicatorClassName={
                  safetyScore >= 80 ? "bg-green-600" : safetyScore >= 60 ? "bg-amber-500" : "bg-red-600"
                }
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Current Location</CardTitle>
              <CardDescription>GPS tracking active</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
                <div>
                  <div className="font-medium">123 Main Street</div>
                  <div className="text-sm text-gray-500">City, State 12345</div>
                  <div className="text-xs text-gray-400 mt-1">Last updated: Just now</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid grid-cols-3 md:w-[400px]">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Current status of all monitoring systems</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <StatusItem
                    icon={<Car className="h-5 w-5" />}
                    title="Vehicle Cameras"
                    status="Active"
                    statusColor="text-green-600"
                  />
                  <StatusItem
                    icon={<AlertTriangle className="h-5 w-5" />}
                    title="Accident Detection"
                    status="Monitoring"
                    statusColor="text-green-600"
                  />
                  <StatusItem
                    icon={<Shield className="h-5 w-5" />}
                    title="Emergency Alert System"
                    status="Ready"
                    statusColor="text-green-600"
                  />
                  <StatusItem
                    icon={<MapPin className="h-5 w-5" />}
                    title="GPS Tracking"
                    status="Active"
                    statusColor="text-green-600"
                  />
                  <StatusItem
                    icon={<Bell className="h-5 w-5" />}
                    title="Guardian Notifications"
                    status="Connected"
                    statusColor="text-green-600"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>System events from the past 24 hours</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <ActivityItem
                    icon={<Car className="h-5 w-5" />}
                    title="Trip Started"
                    description="Vehicle started moving from Home"
                    time="10 minutes ago"
                  />
                  <ActivityItem
                    icon={<AlertTriangle className="h-5 w-5" />}
                    title="Speed Alert"
                    description="Vehicle exceeded speed limit by 5 km/h"
                    time="25 minutes ago"
                  />
                  <ActivityItem
                    icon={<Bell className="h-5 w-5" />}
                    title="Guardian Notification"
                    description="Speed alert sent to Jane Doe"
                    time="25 minutes ago"
                  />
                  <ActivityItem
                    icon={<Shield className="h-5 w-5" />}
                    title="System Check"
                    description="All systems functioning normally"
                    time="1 hour ago"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Alert History</CardTitle>
                <CardDescription>Recent alerts and notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <AlertItem
                    type="speed"
                    description="Vehicle exceeded speed limit by 5 km/h"
                    time="25 minutes ago"
                    severity="medium"
                  />
                  <AlertItem
                    type="system"
                    description="Guardian notification system test successful"
                    time="2 hours ago"
                    severity="low"
                  />
                  <AlertItem
                    type="prediction"
                    description="Potential accident scenario detected but avoided"
                    time="Yesterday, 4:30 PM"
                    severity="high"
                  />
                  <AlertItem
                    type="speed"
                    description="Vehicle exceeded speed limit by 10 km/h"
                    time="Yesterday, 2:15 PM"
                    severity="high"
                  />
                  <AlertItem
                    type="system"
                    description="System update completed successfully"
                    time="2 days ago"
                    severity="low"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Alert Settings</CardTitle>
                <CardDescription>Configure your alert preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <SettingItem
                    title="Speed Limit Alerts"
                    description="Notify when speed exceeds the limit"
                    enabled={true}
                  />
                  <SettingItem
                    title="Guardian Notifications"
                    description="Send alerts to registered guardian"
                    enabled={true}
                  />
                  <SettingItem
                    title="Emergency Service Calls"
                    description="Automatically call 108 in emergencies"
                    enabled={true}
                  />
                  <SettingItem
                    title="Location Tracking"
                    description="Track and record vehicle location"
                    enabled={true}
                  />
                  <SettingItem
                    title="System Status Notifications"
                    description="Receive system status updates"
                    enabled={false}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Driver Profile</CardTitle>
                <CardDescription>Your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center">
                      <User className="h-12 w-12 text-gray-500" />
                    </div>
                  </div>
                  <div className="space-y-3 flex-1">
                    <div>
                      <div className="text-sm font-medium text-gray-500">Full Name</div>
                      <div className="font-medium">John Doe</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-500">Email</div>
                      <div className="font-medium">john@example.com</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-500">Phone</div>
                      <div className="font-medium">+1 (555) 123-4567</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-gray-500">Vehicle Registration</div>
                      <div className="font-medium">ABC-1234</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Guardian Information</CardTitle>
                <CardDescription>Emergency contact details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <div className="text-sm font-medium text-gray-500">Guardian Name</div>
                    <div className="font-medium">Jane Doe</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-500">Relationship</div>
                    <div className="font-medium">Parent</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-500">Email</div>
                    <div className="font-medium">jane@example.com</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-500">Phone</div>
                    <div className="font-medium">+1 (555) 987-6543</div>
                  </div>
                  <div className="pt-2">
                    <Button variant="outline" size="sm">
                      Update Guardian Info
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function StatusItem({
  icon,
  title,
  status,
  statusColor,
}: {
  icon: React.ReactNode
  title: string
  status: string
  statusColor: string
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <div className="bg-gray-100 p-2 rounded-full">{icon}</div>
        <span className="font-medium">{title}</span>
      </div>
      <span className={`font-medium ${statusColor}`}>{status}</span>
    </div>
  )
}

function ActivityItem({
  icon,
  title,
  description,
  time,
}: {
  icon: React.ReactNode
  title: string
  description: string
  time: string
}) {
  return (
    <div className="flex space-x-3">
      <div className="bg-gray-100 p-2 rounded-full h-fit">{icon}</div>
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <span className="font-medium">{title}</span>
          <span className="text-xs text-gray-500">{time}</span>
        </div>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </div>
  )
}

function AlertItem({
  type,
  description,
  time,
  severity,
}: {
  type: "speed" | "system" | "prediction"
  description: string
  time: string
  severity: "low" | "medium" | "high"
}) {
  const getIcon = () => {
    switch (type) {
      case "speed":
        return <Clock className="h-5 w-5" />
      case "system":
        return <Shield className="h-5 w-5" />
      case "prediction":
        return <AlertTriangle className="h-5 w-5" />
    }
  }

  const getTypeLabel = () => {
    switch (type) {
      case "speed":
        return "Speed Alert"
      case "system":
        return "System Notification"
      case "prediction":
        return "Accident Prediction"
    }
  }

  const getSeverityColor = () => {
    switch (severity) {
      case "low":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-amber-100 text-amber-800"
      case "high":
        return "bg-red-100 text-red-800"
    }
  }

  const getSeverityLabel = () => {
    switch (severity) {
      case "low":
        return "Low"
      case "medium":
        return "Medium"
      case "high":
        return "High"
    }
  }

  return (
    <div className="flex space-x-3">
      <div
        className={`p-2 rounded-full h-fit ${
          type === "speed"
            ? "bg-blue-100 text-blue-600"
            : type === "system"
              ? "bg-green-100 text-green-600"
              : "bg-red-100 text-red-600"
        }`}
      >
        {getIcon()}
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-2">
            <span className="font-medium">{getTypeLabel()}</span>
            <Badge className={getSeverityColor()}>{getSeverityLabel()}</Badge>
          </div>
          <span className="text-xs text-gray-500">{time}</span>
        </div>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
      </div>
    </div>
  )
}

function SettingItem({
  title,
  description,
  enabled,
}: {
  title: string
  description: string
  enabled: boolean
}) {
  const [isEnabled, setIsEnabled] = useState(enabled)

  return (
    <div className="flex items-center justify-between">
      <div>
        <div className="font-medium">{title}</div>
        <div className="text-sm text-gray-500">{description}</div>
      </div>
      <div
        className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-red-600 focus:ring-offset-2 bg-gray-200"
        onClick={() => setIsEnabled(!isEnabled)}
        style={{ backgroundColor: isEnabled ? "#dc2626" : "" }}
      >
        <span className="sr-only">Toggle {title}</span>
        <span
          aria-hidden="true"
          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
            isEnabled ? "translate-x-5" : "translate-x-0"
          }`}
        />
      </div>
    </div>
  )
}

