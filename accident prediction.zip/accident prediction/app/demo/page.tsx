"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, ArrowLeft, Car, Clock, MapPin, AlertOctagon, X, PhoneCall } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

export default function DemoPage() {
  const [currentSpeed, setCurrentSpeed] = useState(45)
  const [speedLimit, setSpeedLimit] = useState(60)
  const [showAccidentAlert, setShowAccidentAlert] = useState(false)
  const [countdown, setCountdown] = useState(10)
  const [emergencyDialogOpen, setEmergencyDialogOpen] = useState(false)
  const [demoStage, setDemoStage] = useState(0)
  const [demoText, setDemoText] = useState("Starting demo simulation...")

  // Demo sequence
  useEffect(() => {
    const stages = [
      {
        delay: 2000,
        action: () => {
          setDemoText("Normal driving conditions detected.")
        },
      },
      {
        delay: 5000,
        action: () => {
          setDemoText("Increasing vehicle speed for demonstration...")
          setCurrentSpeed(65)
        },
      },
      {
        delay: 8000,
        action: () => {
          setDemoText("Speed limit exceeded! Guardian notification sent.")
        },
      },
      {
        delay: 12000,
        action: () => {
          setDemoText("AI analyzing driving patterns and road conditions...")
        },
      },
      {
        delay: 15000,
        action: () => {
          setDemoText("Potential accident scenario detected!")
          setShowAccidentAlert(true)
        },
      },
    ]

    if (demoStage < stages.length) {
      const timer = setTimeout(() => {
        stages[demoStage].action()
        setDemoStage(demoStage + 1)
      }, stages[demoStage].delay)

      return () => clearTimeout(timer)
    }
  }, [demoStage])

  // Countdown timer for accident alert
  useEffect(() => {
    let timer: NodeJS.Timeout

    if (showAccidentAlert && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1)
      }, 1000)
    }

    if (countdown === 0) {
      setShowAccidentAlert(false)
      setEmergencyDialogOpen(true)
      setDemoText("Emergency services being contacted...")
    }

    return () => clearInterval(timer)
  }, [showAccidentAlert, countdown])

  const cancelAlert = () => {
    setShowAccidentAlert(false)
    setCountdown(10)
    setDemoText("Alert canceled by user. Resuming normal monitoring.")
  }

  const resetDemo = () => {
    setCurrentSpeed(45)
    setShowAccidentAlert(false)
    setCountdown(10)
    setEmergencyDialogOpen(false)
    setDemoStage(0)
    setDemoText("Starting demo simulation...")
  }

  const getSpeedColor = () => {
    if (currentSpeed > speedLimit) return "text-red-600"
    if (currentSpeed > speedLimit * 0.8) return "text-amber-500"
    return "text-green-600"
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Link href="/" className="flex items-center space-x-2 w-fit">
            <ArrowLeft className="h-4 w-4" />
            <Car className="h-5 w-5 text-red-600" />
            <span className="font-medium">SafeDrive AI</span>
          </Link>
        </div>
      </header>

      {showAccidentAlert && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full mx-4 shadow-lg">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center">
                <AlertOctagon className="h-8 w-8 text-red-600 mr-2" />
                <h2 className="text-xl font-bold text-red-600">Potential Accident Detected!</h2>
              </div>
              <Button variant="ghost" size="icon" onClick={cancelAlert}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <p className="mb-4">
              Our AI has detected a potential accident scenario. Emergency services will be contacted in:
            </p>
            <div className="flex justify-center mb-4">
              <div className="bg-red-100 text-red-600 text-4xl font-bold rounded-full w-20 h-20 flex items-center justify-center">
                {countdown}
              </div>
            </div>
            <p className="text-sm text-gray-500 mb-4 text-center">Press "Cancel Alert" if this is a false alarm</p>
            <Button className="w-full bg-red-600 hover:bg-red-700" onClick={cancelAlert}>
              Cancel Alert
            </Button>
          </div>
        </div>
      )}

      <Dialog open={emergencyDialogOpen} onOpenChange={setEmergencyDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center text-red-600">
              <PhoneCall className="mr-2 h-5 w-5" />
              Emergency Call in Progress
            </DialogTitle>
            <DialogDescription>
              Contacting emergency services (108) with your location and vehicle information.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="h-20 w-20 rounded-full bg-red-100 flex items-center justify-center">
                  <PhoneCall className="h-10 w-10 text-red-600 animate-pulse" />
                </div>
                <div className="absolute -inset-1 rounded-full border-2 border-red-400 animate-ping opacity-75"></div>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">Sharing the following information:</p>
              <ul className="text-sm text-gray-500 space-y-1">
                <li>• Vehicle registration: ABC-1234</li>
                <li>• Current location: 123 Main St, City</li>
                <li>• Driver: John Doe</li>
                <li>• Emergency contact: Jane Doe (Parent)</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="destructive"
              onClick={() => {
                setEmergencyDialogOpen(false)
                setDemoText("Demo completed. You can reset to try again.")
              }}
            >
              End Call
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">SafeDrive AI Demo</h1>
          <p className="text-gray-600 mb-6">
            This interactive demo shows how the SafeDrive AI system works to predict and respond to potential accident
            scenarios.
          </p>

          <Card className="mb-6 border-red-100 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-red-800 mb-1">Demo Mode</h3>
                  <p className="text-red-700 text-sm">
                    This is a simulated demonstration. In a real implementation, the system would connect to actual
                    vehicle sensors, cameras, and emergency services.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle>Demo Status</CardTitle>
              <CardDescription>Current simulation status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-gray-50 rounded-md border mb-4">
                <p className="font-medium">{demoText}</p>
              </div>
              <Button onClick={resetDemo}>Reset Demo</Button>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Current Speed</CardTitle>
              <CardDescription>Vehicle speed monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <div className={`text-4xl font-bold ${getSpeedColor()}`}>
                  {currentSpeed}
                  <span className="text-lg ml-1">km/h</span>
                </div>
                <div className="text-sm text-gray-500">Limit: {speedLimit} km/h</div>
              </div>
              <Progress
                value={(currentSpeed / speedLimit) * 100}
                className="h-2 mt-2"
                indicatorClassName={
                  currentSpeed > speedLimit
                    ? "bg-red-600"
                    : currentSpeed > speedLimit * 0.8
                      ? "bg-amber-500"
                      : "bg-green-600"
                }
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">AI Prediction</CardTitle>
              <CardDescription>Accident risk assessment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2 mb-2">
                <div
                  className={`h-3 w-3 rounded-full ${
                    demoStage >= 4 ? "bg-red-600" : demoStage >= 3 ? "bg-amber-500" : "bg-green-600"
                  }`}
                ></div>
                <span className="font-medium">
                  {demoStage >= 4 ? "High Risk" : demoStage >= 3 ? "Moderate Risk" : "Low Risk"}
                </span>
              </div>
              <Progress
                value={demoStage >= 4 ? 90 : demoStage >= 3 ? 60 : 20}
                className="h-2 mb-2"
                indicatorClassName={demoStage >= 4 ? "bg-red-600" : demoStage >= 3 ? "bg-amber-500" : "bg-green-600"}
              />
              <p className="text-sm text-gray-600">
                {demoStage >= 4
                  ? "AI has detected a potential accident scenario based on current driving patterns and road conditions."
                  : demoStage >= 3
                    ? "AI is analyzing unusual patterns in driving behavior."
                    : "Normal driving conditions detected."}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Current Location</CardTitle>
              <CardDescription>GPS tracking active</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 text-red-600 mt-1 flex-shrink-0" />
                <div>
                  <div className="font-medium">123 Main Street</div>
                  <div className="text-sm text-gray-500">City, State 12345</div>
                  <div className="text-xs text-gray-400 mt-1">Last updated: Just now</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>How This Works</CardTitle>
            <CardDescription>Understanding the SafeDrive AI system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex space-x-3">
                <div className="bg-red-100 p-2 rounded-full h-fit">
                  <Clock className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <h3 className="font-medium">Real-Time Monitoring</h3>
                  <p className="text-sm text-gray-600">
                    The system continuously monitors vehicle speed, location, and sensor data to detect potential
                    accident scenarios.
                  </p>
                </div>
              </div>

              <div className="flex space-x-3">
                <div className="bg-amber-100 p-2 rounded-full h-fit">
                  <AlertTriangle className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-medium">Early Warning System</h3>
                  <p className="text-sm text-gray-600">
                    When a potential accident is detected, the system displays a 10-second warning, allowing the driver
                    to cancel if it's a false alarm.
                  </p>
                </div>
              </div>

              <div className="flex space-x-3">
                <div className="bg-green-100 p-2 rounded-full h-fit">
                  <PhoneCall className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Emergency Response</h3>
                  <p className="text-sm text-gray-600">
                    If the alert isn't canceled, the system automatically contacts emergency services (108) and shares
                    the vehicle's location and driver information.
                  </p>
                </div>
              </div>

              <div className="flex space-x-3">
                <div className="bg-blue-100 p-2 rounded-full h-fit">
                  <Car className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">Guardian Notifications</h3>
                  <p className="text-sm text-gray-600">
                    The system also notifies the registered guardian about speeding incidents and potential accidents,
                    providing peace of mind.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

