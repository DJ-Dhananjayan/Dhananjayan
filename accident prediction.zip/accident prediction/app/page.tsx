import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Car, Shield, Bell } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Car className="h-6 w-6 text-red-600" />
            <h1 className="text-xl font-bold">SafeDrive AI</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/login">
              <Button variant="outline">Login</Button>
            </Link>
            <Link href="/register">
              <Button>Register</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="bg-gradient-to-b from-red-50 to-white py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              AI-Based Accident Prediction & Emergency Alert System
            </h1>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-10">
              Leveraging AI to predict potential accidents in real-time, alert emergency services, and notify guardians
              to keep drivers safe on the road.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/register">
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/demo">
                <Button size="lg" variant="outline">
                  View Demo
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Car className="h-10 w-10 text-red-600" />}
                title="Real-Time Monitoring"
                description="Our AI continuously analyzes vehicle camera feeds, sensor data, GPS, and speed to detect potential accident scenarios."
              />
              <FeatureCard
                icon={<Shield className="h-10 w-10 text-red-600" />}
                title="Instant Alerts"
                description="Receive 10-second warning notifications with the option to cancel false alarms before emergency services are contacted."
              />
              <FeatureCard
                icon={<Bell className="h-10 w-10 text-red-600" />}
                title="Guardian Notifications"
                description="Parents or guardians receive instant alerts about speeding or potential accidents, providing peace of mind."
              />
            </div>
          </div>
        </section>

        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Key Features</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <FeatureList
                title="Accident Prediction"
                items={[
                  "AI-powered real-time accident prediction",
                  "Multi-sensor data analysis",
                  "10-second warning window with cancel option",
                  "Automatic emergency service contact",
                ]}
              />
              <FeatureList
                title="Safety Monitoring"
                items={[
                  "Speed limit monitoring and alerts",
                  "Location tracking with intelligent estimation",
                  "Guardian notification system",
                  "Secure data handling and privacy protection",
                ]}
              />
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 text-white py-10">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Car className="h-6 w-6 text-red-500" />
              <span className="text-xl font-bold">SafeDrive AI</span>
            </div>
            <div className="flex flex-col md:flex-row md:space-x-8">
              <Link href="/about" className="hover:text-red-400 mb-2 md:mb-0">
                About
              </Link>
              <Link href="/privacy" className="hover:text-red-400 mb-2 md:mb-0">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-red-400 mb-2 md:mb-0">
                Terms of Service
              </Link>
              <Link href="/contact" className="hover:text-red-400">
                Contact
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-gray-400">
            <p>© {new Date().getFullYear()} SafeDrive AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 flex flex-col items-center text-center">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

function FeatureList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      <h3 className="text-xl font-semibold mb-4">{title}</h3>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            <div className="mr-2 mt-1 bg-red-600 rounded-full p-1">
              <svg
                className="h-3 w-3 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

